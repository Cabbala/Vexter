# comparison-dexter-resume-after-pr9-20260321T1734-vs-mewx-resume-after-pr9-20260321T1734

## Validation

- Dexter readiness: `partial`
- Mew-X readiness: `partial`
- Winner mode: `deferred`

## Notes

- Fresh same-attempt recollection on 2026-03-21 JST from PR #9 main kept Dexter observe_live and Mew-X sim_live on the zero-balance safety path. Coverage remains partial at Dexter 4/12 and Mew-X 8/12, so winner decisions stay deferred.

## Critical Metrics

| Metric | Dexter | Mew-X |
| --- | --- | --- |
| candidate_count | 146 | 0 |
| candidate_precision_proxy | 0 (0.00%) | unavailable |
| fill_success_rate | unavailable | 1 (100.00%) |
| signal_to_attempt_latency_ms | unavailable | 1190 ms |
| attempt_to_fill_latency_ms | unavailable | 1 ms |
| quote_vs_fill_slippage_bps | unavailable | -885.5531 bps |
| max_favorable_excursion_pct | unavailable | 4.5401 pct |
| max_adverse_excursion_pct | unavailable | 0 pct |
| time_to_peak_ms | unavailable | 9 ms |
| realized_exit_pct | unavailable | 0 pct |
| realized_vs_peak_gap_pct | unavailable | 4.5401 pct |
| stale_position_ratio | unavailable | 1 (100.00%) |
| replayability_grade | partial | partial |

## Decision

- Winning component candidates: deferred until both matched-window packages validate beyond `partial`.
- Evidence still missing: pass-grade live validation, especially fill / exit / run-summary coverage on the matched pair.
- Next task: keep TASK-005 open, collect a fuller comparable matched window, and rerun replay readiness only after that; TASK-006 remains blocked.
