# TASK-007-PLANNER-ROUTER-LIVEPAPER-SMOKE

## Scope

This task starts from merged PR `#41` and the completed `TASK-007-MONITOR-KILLSWITCH-SPEC` lane. It keeps the promoted comparison baseline frozen and asks one bounded execution question:

- Does the fixed planner/router control plane still hold end to end once immutable plans are handed to source-faithful paper-like executor seams?

The task stays intentionally narrow:

- no new evidence collection
- no Dexter or Mew-X source-logic changes
- no validator-rule changes
- no comparison baseline reopen
- no source-transport implementation
- no numeric timeout, retry, heartbeat, or cap finalization
- only live-paper smoke coverage, companion artifacts, and refreshed bundle metadata

## Verified GitHub State

- Latest merged Vexter `main`: PR `#41`, main commit `0b174515c9c0deb04b70fd38c2c2882736a22273`, merged at `2026-03-26T03:08:04Z`
- Supporting merged Vexter states: PR `#40` `a4e7a3c74460dc711c3e2897ac31386272e91c27`; PR `#39` `a293d6e9260bd092297140bc82469802d6fce115`; PR `#38` `b1ceac48af931db0571a25ea197b1e4e5df52543`; PR `#37` `786221a664637925f790e89af0448fa04832426e`; PR `#36` `8713b9ba8de82accda48526fdff8732531d7b620`; PR `#35` `2bec1badde788ef1c75251af2df17609643720fb`; PR `#34` `981f0977788cffd10de4bf78f14e5b430fbce4c1`; PR `#33` `c6dfaee621e3eea08ceec1cfba7f0fe65a5918fc`; PR `#32` `a214ff04f0662e250b01181551a8963ce8e80dd6`; PR `#31` `0905ec8c991ca6046b13d0c326c3224c49709a2d`; PR `#30` `052de6ccecef1461d2291fb4f0ef5fbf8883d548`; PR `#29` `17af013b0383fd142e15932108c8b4da5447f1f7`; PR `#28` `4df259b90365787ac24085227fcc1b15b63d057d`; PR `#27` `d8149e624b9682e2da55ac4bfcaa30fcaa3d94df`; PR `#26` `9d235176e628e0fcbdcf2182ce83def25f6a6b02`; PR `#25` `727589b40d26c453c2fef78dc5060aa1098c1aad`; PR `#24` `2c8b654fde4b4fcff11f3ecca2e1f4d27ceb610d`; PR `#23` `eaa5acc2f189d5bea5c55f9de059d8e6a8d36091`; PR `#22` `3db6d3e73c4a6d990e0fdf8fba33b31a3a436c5b`; PR `#21` `d7845b665afc912da593f2601e6a3d39524964d0`; PR `#20` `6f2f50cc14dddfa52e6632db1dcbb98dbdb8a668`; PR `#19` `db59c2edc099c4e794d8e0ac177cedb6f6d57d2d`; PR `#18` `b7c8cb900ced104f4fe76cfd9ca48c2b21b82d81`; PR `#17` `b09033d6c8ce21510da23025cee935e46f3ef4df`
- Dexter merged `main`: PR `#3`, `ddeb18c0dd21fa3a15d4a6a85573428f7d7ae938`
- Frozen Mew-X: `dba3dc84f1e2d4efc90fa5a4561593edcc9dd37a`

## Fixed Input Surface

- Promoted baseline: `task005-pass-grade-pair-20260325T180027Z`
- Comparison source of truth: `comparison_closed_out`
- Prior monitor/kill-switch report: `artifacts/reports/task-007-monitor-killswitch-spec-report.md`
- Prior monitor/kill-switch proof: `artifacts/proofs/task-007-monitor-killswitch-spec-check.json`
- Current inherited implementation conclusion: `monitor_killswitch_contract_fixed`
- Current inherited claim boundary: `monitor_killswitch_spec_bounded`
- Confirmatory residual context: `Mew-X candidate_rejected`

Facts preserved from comparison closeout through live-paper smoke:

- live winner mode: `derived`
- replay winner mode: `derived`
- stable scored split: Dexter `6`, Mew-X `4`, tie `2`
- Dexter replay coverage / gap: `100.00%` / `0.0000`
- Mew-X replay coverage / gap: `100.00%` / `0.0000`
- default execution anchor: `Dexter`
- selective sleeve source: `Mew-X`
- global halt mode remains `manual_latched_stop_all`
- externally visible lifecycle stays `planned -> starting -> running -> quarantined -> stopping -> stopped|failed`

## What Landed

### Admission gate on live-paper requests

Live-paper admission still fails closed before any plan batch is emitted. The smoke proves that an active planner global halt rejects a live-paper overlay request with typed `global_halt_active` failure and leaves the plan store empty.

### Immutable paper-seam handoff

`plan_request()` now has direct live-paper smoke evidence against source-faithful stub seams:

- Dexter plan handoff uses `paper_live`
- Mew-X plan handoff uses `sim_live`
- pinned commits, normalized statuses, monitor profile ids, timeout envelope classes, and per-sleeve budget shares are preserved on the native handle
- immutable plan invariants are unchanged before dispatch

### Dispatch start and bounded runtime progression

`plan_and_dispatch()` now has live-paper smoke coverage for the overlay route:

- Dexter plan starts and reports running on the paper seam
- Mew-X plan starts and reports running on the sim-live seam
- runtime stays on the bounded public path instead of rebinding or widening the lifecycle surface

### Profile-bound quarantine and manual halt

The live-paper runtime smoke proves the current monitor contract survives the paper seam:

- Mew-X quarantine carries `mewx_timeout_guard`, `mewx_timeout_tolerant`, and sleeve-local scope into the runtime signal
- quarantine remains source-local and does not trigger cross-source handoff
- `manual_latched_stop_all` propagates to both active plans in reverse order once quarantine escalates
- stop requests remain source-native and end in `stopped`

## What Did Not Change

- No Dexter source behavior changed.
- No Mew-X source behavior changed.
- No validator rules changed.
- No comparison evidence was recollected.
- No numeric timeout, retry, heartbeat, or budget threshold was finalized.

## Tests

Live-paper coverage now includes:

- `tests/test_planner_router_livepaper_smoke.py`
- `tests/test_planner_router_runtime_smoke.py`
- `tests/test_monitor_killswitch_spec_contract.py`
- `tests/test_bootstrap_layout.py`

Validation run on this branch:

- `pytest -q`
- `61 passed`

## Recommendation Among Next Tasks

### `planner_router_executor_transport_spec`

Recommended next because:

- live-paper behavior is now smoke-proven only at the stubbed executor seam, so the remaining bounded gap is how real transport start, status, and stop calls are shaped
- executor-boundary basics are already fixed enough to support the current smoke
- observability should sit on a transport boundary that is frozen first

### `executor_boundary_spec`

Not next because:

- the adapter, pin, normalized-status, and monitor-binding surfaces are already fixed well enough to carry the live-paper smoke
- another boundary-only pass would mostly restate the contract that is now already exercised

### `livepaper_observability_spec`

Not next because:

- observability is valuable, but the tighter missing boundary is still transport ownership and call shape
- the current live-paper smoke already proves the planner/router lifecycle without needing a broader telemetry contract first

## Decision

- Outcome: `A`
- Key finding: `planner_router_livepaper_smoke_passed`
- Claim boundary: `livepaper_smoke_bounded`
- Current task status: `planner_router_livepaper_smoke_passed`
- Recommended next step: `planner_router_executor_transport_spec`
- Decision: `planner_router_executor_transport_spec_ready`
